import os
import pickle
from random import sample
import numpy as np
import torch
import torch.utils.data as data
from PIL import Image
from torch.utils.data import DataLoader
from config import argument_parser
from tools.function import get_pkl_rootpath
import torchvision.transforms as T
from operator import itemgetter 




class MultiModalAttrDataset(data.Dataset):

    def __init__(self, split, args, transform=None, target_transform=None):

        #data_path = get_pkl_rootpath(args.dataset)
        assert args.dataset in ['MARS', 'DUKE'], \
            f'dataset name {args.dataset} is not exist,The legal name is MARS, DUKE'
        if args.dataset =='MARS' :
            data_path='/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c0/DATA/yanghaoxiang/VBT/dataset/MARS/pad.pkl'
        else :
            data_path='/amax/DATA/jinjiandong/VTB-main/dataset/DUKE_MCMT/pad_duke.pkl'

        dataset_info = pickle.load(open(data_path, 'rb+'))
        
        
        track_id = dataset_info.track_name
        track_event_id = dataset_info.track_event_name
        attr_label = dataset_info.label

        assert split in dataset_info.partition.keys(), f'split {split} is not exist'
        self.frames=args.frames
        self.dataset = args.dataset
        self.transform = transform
        self.target_transform = target_transform

        self.root_path = dataset_info.root

        self.attr_id = dataset_info.attr_name
        self.attr_num = len(self.attr_id)
        self.attributes=dataset_info.attr_name
        self.track_idx=dataset_info.partition[split]#{'test': array([1318, ...1978]), 'trainval': array([   0,    1,    2, ..., 1315, 1316, 1317])}
        
        
        if isinstance(self.track_idx, list):
            self.track_idx = self.track_idx[0]
        self.track_num = self.track_idx.shape[0]#1318

       
        self.track_id = [track_id[i] for i in self.track_idx]
        self.track_event_id = [track_event_id[i] for i in self.track_idx]

        self.label = np.array(itemgetter(*self.track_id)(dataset_info.result_dict))#array([[1., 0., 0., 0., 0.],       [1., 0., 0., 0., 0.],       [1., 0., 0., 0., 0.],       ...,       [0., 0., 0., 0., 1.],   [0., 0., 0., 0., 1.],       [0., 0., 0., 0., 1.]])
        
        self.label_all = self.label

        self.label_word = dataset_info.words
        self.label_vector=dataset_info.attr_vectors
        self.words = self.label_word.tolist()


        self.track_imgs_path=dataset_info.track_imgs_path
        self.track_event_path=dataset_info.track_event_path
        self.result_dict=dataset_info.result_dict
        self.result_event_dict=dataset_info.result_event_dict#检查过了
        
    def __getitem__(self, index):
        
        trackname= self.track_id[index]
        trackeventname= self.track_event_id[index]
        gt_label = self.result_dict[trackname]
        gt_event_label = self.result_event_dict[trackeventname]
        gt_label=np.array(gt_label)
        gt_event_label = np.array(gt_event_label)
        track_img_path =self.track_imgs_path[trackname]
        track_event_path =self.track_event_path[trackeventname]
                
        imgs = []
        if len(track_img_path) <= (self.frames-1):
            my_sample = np.random.choice(track_img_path, self.frames)
        else:
            my_sample = sample(track_img_path, self.frames)

        for i in my_sample:
            pil = Image.open(i)
            imgs.append(pil)

        if len(imgs) < self.frames:
            while len(imgs) < self.frames:
                random_image = np.random.choice(track_img_path)
                pil = Image.open(random_image)
                imgs.append(pil)
        
        event = []
        if len(track_event_path) <= (self.frames-1):
            my_sample = np.random.choice(track_event_path, self.frames)
        else:
            my_sample = sample(track_event_path, self.frames)

        for i in my_sample:
            pil = Image.open(i)
            event.append(pil)

        if len(event) < self.frames:
            while len(event) < self.frames:
                random_event = np.random.choice(track_event_path)
                pil = Image.open(random_event)
                event.append(pil)




        imgs_trans=[]
        if self.transform is not None:
            for i in imgs:
                imgs_trans.append(self.transform(i))


        event_trans=[]
        if self.transform is not None:
            for i in event:
                event_trans.append(self.transform(i))

        gt_label = gt_label.astype(np.float32)
        gt_event_label = gt_event_label.astype(np.float32)
        label_v=self.label_vector.astype(np.float32)
        
        if self.target_transform is not None:
            gt_label = self.transform(gt_label)
            gt_event_label = self.transform(gt_event_label)
        
        return torch.stack(imgs_trans), gt_label,trackname,label_v, torch.stack(event_trans), gt_event_label, trackeventname
    def __len__(self):
        return len(self.track_id)


def get_transform(args):
    height = args.height
    width = args.width
    normalize = T.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    train_transform = T.Compose([
        T.Resize((height, width)),
        T.Pad(10),
        T.RandomCrop((height, width)),
        T.RandomHorizontalFlip(),
        T.ToTensor(),
        normalize,
    ])

    valid_transform = T.Compose([
        T.Resize((height, width)),
        T.ToTensor(),
        normalize
    ])

    return train_transform, valid_transform
