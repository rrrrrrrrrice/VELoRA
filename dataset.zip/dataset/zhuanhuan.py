import pickle

def replace_uuid(obj, old_uuid, new_uuid):
    if isinstance(obj, dict):
        for key in obj:
            obj[key] = replace_uuid(obj[key], old_uuid, new_uuid)
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            obj[i] = replace_uuid(item, old_uuid, new_uuid)
    elif isinstance(obj, str):
        return obj.replace(old_uuid, new_uuid)
    return obj

def main():
    old_uuid = '836e911f-c5c3-4c4b-91f2-41bb8f3f5cb6'
    new_uuid = 'c08a625b-023d-436f-b33e-9652dc1bc7c0'

    with open('/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c0/DATA/yanghaoxiang/VBT/dataset/MARS/pad.pkl', 'rb') as f:
        data = pickle.load(f)

    data = replace_uuid(data, old_uuid, new_uuid)

    with open('/media/amax/c08a625b-023d-436f-b33e-9652dc1bc7c0/DATA/yanghaoxiang/VBT/dataset/MARS/pad.pkl', 'wb') as f:
        pickle.dump(data, f)

if __name__ == "__main__":
    main()
